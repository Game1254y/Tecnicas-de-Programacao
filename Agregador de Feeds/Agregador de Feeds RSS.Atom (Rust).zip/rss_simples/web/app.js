// Este arquivo faz a página "conversar" com o programa Rust:
// ele envia pedidos (fetch) para a API e desenha o resultado na tela.

// O que o usuário escolheu filtrar neste momento.
const state = { feed: null, mode: "all", search: "" };

const $ = (id) => document.getElementById(id);

// Cria um elemento HTML. Usamos textContent (e não innerHTML) para que
// textos vindos dos feeds nunca sejam interpretados como código.
function el(tag, props = {}, ...children) {
  const node = Object.assign(document.createElement(tag), props);
  node.append(...children);
  return node;
}

// Faz um pedido à API do Rust e devolve a resposta já convertida de JSON.
async function api(path, method = "GET", body) {
  const response = await fetch(path, {
    method,
    headers: body ? { "Content-Type": "application/json" } : {},
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || "Erro desconhecido");
  return data;
}

function showStatus(message, isError = false) {
  const box = $("status");
  box.textContent = message;
  box.className = isError ? "status error" : "status";
}

// Os resumos dos feeds vêm com HTML; aqui extraímos só o texto, com segurança.
function plainText(html) {
  return new DOMParser().parseFromString(html, "text/html").body.textContent.trim();
}

const isWebLink = (url) => /^https?:\/\//i.test(url || "");

// ---------------------------------------------------------------- Feeds

async function loadFeeds() {
  const feeds = await api("/api/feeds");
  const list = $("feed-list");
  list.replaceChildren(feedItem(null, "Todos os feeds", "Mostrar artigos de todos", ""));

  if (feeds.length === 0) {
    list.append(el("li", { className: "feed-meta", textContent: "Nenhum feed cadastrado ainda." }));
  }
  for (const f of feeds) {
    const [badge, label] = f.last_error
      ? ["error", `erro (${f.failure_count}x)`]
      : f.last_success ? ["ok", "ok"] : ["new", "novo"];
    const meta = f.last_error || f.url;
    list.append(feedItem(f.id, f.title || f.url, meta, badge, label));
  }
}

function feedItem(id, name, meta, badge, label) {
  const pick = el("button", { className: "feed-pick", title: meta },
    el("span", { className: "feed-name", textContent: name }),
    el("span", { className: "feed-meta" },
      ...(badge ? [el("span", { className: `badge ${badge}`, textContent: label })] : []),
      meta));
  pick.onclick = () => { state.feed = id; refresh(); };

  const item = el("li", { className: "feed-item" + (state.feed === id ? " active" : "") }, pick);
  if (id !== null) {
    item.append(el("button", { className: "icon-btn", title: "Remover feed", textContent: "✕", onclick: () => removeFeed(id) }));
  }
  return item;
}

async function removeFeed(id) {
  if (!confirm("Remover este feed e todos os seus artigos?")) return;
  await api(`/api/feeds/${id}`, "DELETE");
  if (state.feed === id) state.feed = null;
  refresh();
}

$("add-form").onsubmit = async (event) => {
  event.preventDefault();
  const msg = $("form-msg");
  try {
    await api("/api/feeds", "POST", { url: $("feed-url").value });
    msg.textContent = "Feed cadastrado! Clique em “Atualizar todos os feeds”.";
    msg.className = "msg ok";
    $("feed-url").value = "";
    loadFeeds();
  } catch (error) {
    msg.textContent = error.message;
    msg.className = "msg error";
  }
};

// ---------------------------------------------------------------- Atualização

$("update-btn").onclick = async () => {
  const button = $("update-btn");
  button.disabled = true;
  button.textContent = "Atualizando…";
  try {
    const lines = await api("/api/update", "POST");
    $("update-log").replaceChildren(...lines.map((line) => {
      const css = line.startsWith("[ERRO]") ? "error" : line.startsWith("[sem") ? "same" : "";
      return el("li", { className: css, textContent: line });
    }));
    $("log-card").hidden = false;
    await refresh();
  } catch (error) {
    showStatus(error.message, true);
  } finally {
    button.disabled = false;
    button.textContent = "Atualizar todos os feeds";
  }
};

// ---------------------------------------------------------------- Artigos

async function loadArticles() {
  const query = new URLSearchParams();
  if (state.feed !== null) query.set("feed", state.feed);
  if (state.mode === "unread") query.set("unread", "1");
  if (state.mode === "fav") query.set("fav", "1");
  if (state.search.trim()) query.set("search", state.search.trim());

  const articles = await api(`/api/articles?${query}`);
  const box = $("articles");
  box.replaceChildren(...articles.map(articleCard));
  if (articles.length === 0) {
    box.append(el("div", { className: "empty", textContent: "Nenhum artigo encontrado. Cadastre um feed e clique em “Atualizar”." }));
  }
  showStatus(`${articles.length} artigo(s) exibido(s) (máximo de 30 por vez).`);
}

function articleCard(a) {
  const title = isWebLink(a.link)
    ? el("a", { href: a.link, target: "_blank", rel: "noopener noreferrer", textContent: a.title })
    : el("span", { textContent: a.title });

  const date = new Date(a.published || a.fetched_at).toLocaleDateString("pt-BR");
  const meta = [a.feed_title, a.author, date].filter(Boolean).join(" · ");

  const summary = a.summary ? plainText(a.summary) : "";
  const shortSummary = summary.length > 280 ? summary.slice(0, 280) + "…" : summary;

  const readButton = el("button", {
    className: "btn",
    textContent: a.is_read ? "Marcar como não lido" : "Marcar como lido",
    onclick: () => act(a.id, a.is_read ? "unread" : "read"),
  });
  const favButton = el("button", {
    className: "btn" + (a.is_favorite ? " on" : ""),
    textContent: a.is_favorite ? "★ Favorito" : "☆ Favoritar",
    onclick: () => act(a.id, a.is_favorite ? "unfav" : "fav"),
  });

  return el("article", { className: "article" + (a.is_read ? " read" : "") },
    el("h3", {}, title),
    el("p", { className: "meta", textContent: meta }),
    ...(shortSummary ? [el("p", { className: "summary", textContent: shortSummary })] : []),
    el("div", { className: "actions" }, readButton, favButton));
}

async function act(id, action) {
  try {
    await api(`/api/articles/${id}/${action}`, "POST");
    loadArticles();
  } catch (error) {
    showStatus(error.message, true);
  }
}

// ---------------------------------------------------------------- Filtros

$("tabs").onclick = (event) => {
  if (!event.target.dataset.mode) return;
  state.mode = event.target.dataset.mode;
  document.querySelectorAll(".tab").forEach((tab) => tab.classList.toggle("active", tab === event.target));
  loadArticles();
};

// Espera o usuário parar de digitar (300 ms) antes de pesquisar.
let searchTimer;
$("search").oninput = (event) => {
  clearTimeout(searchTimer);
  searchTimer = setTimeout(() => { state.search = event.target.value; loadArticles(); }, 300);
};

// ---------------------------------------------------------------- Início

async function refresh() {
  try {
    await Promise.all([loadFeeds(), loadArticles()]);
  } catch (error) {
    showStatus(error.message, true);
  }
}

refresh();
