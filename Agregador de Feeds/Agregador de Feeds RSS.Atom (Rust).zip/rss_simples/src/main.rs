//! Interface de linha de comando.

mod db;
mod feed;
mod web;

use db::{Article, Db, Feed, Filter};
use feed::Fetched;
use futures::stream::{self, StreamExt};
use std::error::Error;

/// Máximo de feeds sendo baixados ao mesmo tempo.
const MAX_CONCURRENT: usize = 5;

const USAGE: &str = "Comandos:
  add <url> | remove <id> | feeds | update
  serve   (abre a interface web em http://127.0.0.1:3000)
  list [--unread] [--fav] [--feed ID] [--search TEXTO]
  read <id> | unread <id> | fav <id> | unfav <id>";

#[tokio::main]
async fn main() {
    if let Err(e) = run().await {
        eprintln!("Erro: {e}");
        std::process::exit(1);
    }
}

async fn run() -> Result<(), Box<dyn Error>> {
    let args: Vec<String> = std::env::args().skip(1).collect();
    let db = Db::open("rss.db")?;

    match args.first().map(String::as_str) {
        Some("add") => {
            let url = args.get(1).ok_or("uso: add <url>")?;
            feed::validate_url(url)?;
            if db.add_feed(url)? {
                println!("Feed cadastrado. Rode `update` para buscar os artigos.");
            } else {
                println!("Esse feed já está cadastrado.");
            }
        }
        Some("remove") => {
            let removed = db.remove_feed(id_arg(&args)?)?;
            println!(
                "{}",
                if removed {
                    "Feed removido."
                } else {
                    "Feed não encontrado."
                }
            );
        }
        Some("feeds") => print_feeds(&db)?,
        Some("update") => update_all(&db)
            .await?
            .iter()
            .for_each(|line| println!("{line}")),
        Some("serve") => {
            // O servidor web é "bloqueante"; roda em outra thread para não travar o tokio.
            let runtime = tokio::runtime::Handle::current();
            tokio::task::spawn_blocking(move || web::serve(db, runtime))
                .await?
                .map_err(|e| e.to_string())?;
        }
        Some("list") => print_articles(&db, &parse_filter(&args[1..])?)?,
        Some("read") => print_result(db.set_read(id_arg(&args)?, true)?),
        Some("unread") => print_result(db.set_read(id_arg(&args)?, false)?),
        Some("fav") => print_result(db.set_favorite(id_arg(&args)?, true)?),
        Some("unfav") => print_result(db.set_favorite(id_arg(&args)?, false)?),
        _ => println!("{USAGE}"),
    }
    Ok(())
}

/// Atualiza todos os feeds: rede em paralelo, banco em sequência.
/// Devolve uma mensagem por feed (a CLI imprime; a interface web exibe na tela).
async fn update_all(db: &Db) -> Result<Vec<String>, Box<dyn Error>> {
    let feeds = db.list_feeds()?;
    if feeds.is_empty() {
        return Ok(vec!["Nenhum feed cadastrado.".to_string()]);
    }
    let client = feed::client()?;

    // 1) baixa e interpreta até MAX_CONCURRENT feeds ao mesmo tempo
    let results: Vec<_> = stream::iter(feeds)
        .map(|f| {
            let client = client.clone();
            async move {
                let result = feed::fetch(
                    &client,
                    &f.url,
                    f.etag.as_deref(),
                    f.last_modified.as_deref(),
                )
                .await;
                (f, result)
            }
        })
        .buffer_unordered(MAX_CONCURRENT)
        .collect()
        .await;

    // 2) grava cada resultado; um problema em um feed não impede os outros
    Ok(results
        .into_iter()
        .map(|(feed, result)| {
            save_result(db, &feed, result)
                .unwrap_or_else(|e| format!("[ERRO] {}: falha ao gravar no banco: {e}", feed.url))
        })
        .collect())
}

/// Grava no banco o resultado de um feed e devolve a mensagem para o usuário.
fn save_result(db: &Db, feed: &Feed, result: Result<Fetched, String>) -> rusqlite::Result<String> {
    Ok(match result {
        Ok(Fetched::NotModified) => {
            db.save_not_modified(feed.id)?;
            format!("[sem mudanças] {}", feed.url)
        }
        Ok(Fetched::Updated {
            title,
            articles,
            etag,
            last_modified,
        }) => {
            let new = db.save_success(
                feed.id,
                title.as_deref(),
                etag.as_deref(),
                last_modified.as_deref(),
                &articles,
            )?;
            format!("[ok] {} -> {new} novo(s) de {}", feed.url, articles.len())
        }
        Err(error) => {
            db.save_failure(feed.id, &error)?;
            format!("[ERRO] {} -> {error}", feed.url)
        }
    })
}

fn print_feeds(db: &Db) -> rusqlite::Result<()> {
    for f in db.list_feeds()? {
        let status = match (&f.last_error, &f.last_success) {
            (Some(e), _) => format!("COM ERRO ({}x): {e}", f.failure_count),
            (None, Some(_)) => "ok".to_string(),
            (None, None) => "nunca atualizado".to_string(),
        };
        println!(
            "#{} {} [{status}]",
            f.id,
            f.title.as_deref().unwrap_or(&f.url)
        );
        println!(
            "      última consulta: {}",
            f.last_checked.as_deref().unwrap_or("-")
        );
    }
    Ok(())
}

fn print_articles(db: &Db, filter: &Filter) -> rusqlite::Result<()> {
    let articles = db.list_articles(filter)?;
    if articles.is_empty() {
        println!("Nenhum artigo.");
    }
    for a in &articles {
        println!(
            "{}{} #{} {} | {} | {}",
            if a.is_read { " " } else { "●" },
            if a.is_favorite { "★" } else { " " },
            a.id,
            date(a),
            a.feed_title,
            a.title
        );
        println!(
            "      {} - {}",
            a.author.as_deref().unwrap_or("autor desconhecido"),
            a.link.as_deref().unwrap_or("(sem link)")
        );
    }
    Ok(())
}

/// Data (AAAA-MM-DD) de publicação, ou de obtenção se o feed não informou.
fn date(a: &Article) -> &str {
    let full = a.published.as_deref().unwrap_or(&a.fetched_at);
    full.get(..10).unwrap_or(full)
}

/// Converte as opções de `list` (--unread, --fav, --feed, --search) em um filtro.
fn parse_filter(args: &[String]) -> Result<Filter, String> {
    let mut filter = Filter::default();
    let mut args = args.iter();
    while let Some(arg) = args.next() {
        match arg.as_str() {
            "--unread" => filter.unread_only = true,
            "--fav" => filter.favorites_only = true,
            "--feed" => {
                let id = args.next().ok_or("--feed precisa de um ID")?;
                filter.feed_id = Some(id.parse().map_err(|_| "ID de feed inválido")?);
            }
            "--search" => {
                filter.search = Some(args.next().ok_or("--search precisa de um texto")?.clone())
            }
            other => return Err(format!("opção desconhecida: {other}")),
        }
    }
    Ok(filter)
}

fn id_arg(args: &[String]) -> Result<i64, String> {
    args.get(1)
        .ok_or("faltou o ID")?
        .parse()
        .map_err(|_| "ID inválido".to_string())
}

fn print_result(found: bool) {
    println!(
        "{}",
        if found {
            "Feito."
        } else {
            "ID não encontrado."
        }
    );
}

#[cfg(test)]
mod tests {
    use super::*;

    fn args(list: &[&str]) -> Vec<String> {
        list.iter().map(|s| s.to_string()).collect()
    }

    #[test]
    fn le_opcoes_do_list() {
        let f = parse_filter(&args(&["--unread", "--feed", "3", "--search", "rust"])).unwrap();
        assert!(f.unread_only && !f.favorites_only);
        assert_eq!(f.feed_id, Some(3));
        assert_eq!(f.search.as_deref(), Some("rust"));
    }

    #[test]
    fn opcoes_invalidas_viram_erro() {
        assert!(parse_filter(&args(&["--banana"])).is_err());
        assert!(parse_filter(&args(&["--feed"])).is_err());
        assert!(parse_filter(&args(&["--feed", "abc"])).is_err());
    }
}
