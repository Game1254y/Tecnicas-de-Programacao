//! Servidor web local: entrega a página (HTML/CSS/JS) e responde a uma pequena API JSON.
//! A página nunca acessa o banco diretamente: ela pede tudo a este módulo.

use crate::db::{Db, Filter};
use crate::{feed, update_all};
use reqwest::Url;
use serde::{de::DeserializeOwned, Deserialize, Serialize};
use std::error::Error;
use std::io::{Cursor, Read};
use tiny_http::{Header, Method, Request, Response, Server};

/// Só aceita conexões do próprio computador.
const ADDRESS: &str = "127.0.0.1:3000";

type Reply = Response<Cursor<Vec<u8>>>;

/// Erro da API: código HTTP + mensagem (enviado ao navegador como JSON).
struct ApiError(u16, String);

impl From<rusqlite::Error> for ApiError {
    fn from(e: rusqlite::Error) -> Self {
        ApiError(500, e.to_string())
    }
}

fn bad_request(msg: impl Into<String>) -> ApiError {
    ApiError(400, msg.into())
}

pub fn serve(db: Db, runtime: tokio::runtime::Handle) -> Result<(), Box<dyn Error + Send + Sync>> {
    let server = Server::http(ADDRESS)?;
    println!("Interface pronta: abra http://{ADDRESS} no navegador (Ctrl+C para parar).");

    for mut request in server.incoming_requests() {
        let reply = match handle(&db, &runtime, &mut request) {
            Ok(reply) => reply,
            Err(ApiError(code, msg)) => {
                json(&serde_json::json!({ "error": msg })).with_status_code(code)
            }
        };
        let _ = request.respond(reply); // se o navegador já fechou a conexão, não há o que fazer
    }
    Ok(())
}

/// Decide o que fazer conforme o método (GET/POST/DELETE) e o caminho da URL.
fn handle(db: &Db, runtime: &tokio::runtime::Handle, req: &mut Request) -> Result<Reply, ApiError> {
    let url = Url::parse(&format!("http://localhost{}", req.url()))
        .map_err(|_| bad_request("URL inválida"))?;
    let segments: Vec<&str> = url.path_segments().map(|s| s.collect()).unwrap_or_default();

    match (req.method().clone(), segments.as_slice()) {
        // --- página e arquivos estáticos (embutidos no programa) ---
        (Method::Get, [""]) => Ok(file(
            include_str!("../web/index.html"),
            "text/html; charset=utf-8",
        )),
        (Method::Get, ["style.css"]) => Ok(file(
            include_str!("../web/style.css"),
            "text/css; charset=utf-8",
        )),
        (Method::Get, ["app.js"]) => Ok(file(
            include_str!("../web/app.js"),
            "text/javascript; charset=utf-8",
        )),

        // --- feeds ---
        (Method::Get, ["api", "feeds"]) => Ok(json(&db.list_feeds()?)),
        (Method::Post, ["api", "feeds"]) => {
            #[derive(Deserialize)]
            struct NewFeed {
                url: String,
            }
            let new_feed: NewFeed = read_json(req)?;
            let url = new_feed.url.trim();
            feed::validate_url(url).map_err(bad_request)?;
            if !db.add_feed(url)? {
                return Err(bad_request("Esse feed já está cadastrado."));
            }
            Ok(json(&"ok"))
        }
        (Method::Delete, ["api", "feeds", id]) => {
            found(db.remove_feed(parse_id(id)?)?, "feed não encontrado")
        }
        (Method::Post, ["api", "update"]) => {
            let messages = runtime
                .block_on(update_all(db))
                .map_err(|e| ApiError(500, e.to_string()))?;
            Ok(json(&messages))
        }

        // --- artigos ---
        (Method::Get, ["api", "articles"]) => {
            Ok(json(&db.list_articles(&filter_from_query(&url)?)?))
        }
        (Method::Post, ["api", "articles", id, action]) => {
            let id = parse_id(id)?;
            let changed = match *action {
                "read" => db.set_read(id, true)?,
                "unread" => db.set_read(id, false)?,
                "fav" => db.set_favorite(id, true)?,
                "unfav" => db.set_favorite(id, false)?,
                _ => return Err(ApiError(404, "ação desconhecida".into())),
            };
            found(changed, "artigo não encontrado")
        }

        _ => Err(ApiError(404, "não encontrado".into())),
    }
}

/// Lê os filtros da URL: /api/articles?unread=1&fav=1&feed=2&search=rust
fn filter_from_query(url: &Url) -> Result<Filter, ApiError> {
    let mut filter = Filter::default();
    for (key, value) in url.query_pairs() {
        match key.as_ref() {
            "unread" => filter.unread_only = value == "1",
            "fav" => filter.favorites_only = value == "1",
            "feed" => {
                filter.feed_id = Some(
                    value
                        .parse()
                        .map_err(|_| bad_request("ID de feed inválido"))?,
                )
            }
            "search" => filter.search = Some(value.into_owned()),
            _ => {}
        }
    }
    Ok(filter)
}

fn parse_id(text: &str) -> Result<i64, ApiError> {
    text.parse().map_err(|_| bad_request("ID inválido"))
}

fn found(changed: bool, not_found_msg: &str) -> Result<Reply, ApiError> {
    if changed {
        Ok(json(&"ok"))
    } else {
        Err(ApiError(404, not_found_msg.into()))
    }
}

fn read_json<T: DeserializeOwned>(req: &mut Request) -> Result<T, ApiError> {
    let mut body = String::new();
    req.as_reader()
        .take(100_000) // limite de tamanho do corpo
        .read_to_string(&mut body)
        .map_err(|_| bad_request("corpo da requisição inválido"))?;
    serde_json::from_str(&body).map_err(|_| bad_request("JSON inválido"))
}

fn json<T: Serialize>(value: &T) -> Reply {
    let body = serde_json::to_vec(value).unwrap_or_default();
    Response::from_data(body).with_header(header("Content-Type", "application/json; charset=utf-8"))
}

fn file(content: &'static str, content_type: &str) -> Reply {
    Response::from_string(content).with_header(header("Content-Type", content_type))
}

fn header(name: &str, value: &str) -> Header {
    // Só é chamada com textos fixos do programa, que são cabeçalhos válidos.
    Header::from_bytes(name, value).expect("cabeçalho HTTP válido")
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn le_filtros_da_url() {
        let url = Url::parse("http://localhost/api/articles?unread=1&feed=2&search=caf%C3%A9+rust")
            .unwrap();
        let f = filter_from_query(&url).ok().unwrap();
        assert!(f.unread_only && !f.favorites_only);
        assert_eq!(f.feed_id, Some(2));
        assert_eq!(f.search.as_deref(), Some("café rust"));
    }

    #[test]
    fn id_de_feed_invalido_vira_erro_400() {
        let url = Url::parse("http://localhost/api/articles?feed=abc").unwrap();
        assert!(matches!(filter_from_query(&url), Err(ApiError(400, _))));
    }
}
