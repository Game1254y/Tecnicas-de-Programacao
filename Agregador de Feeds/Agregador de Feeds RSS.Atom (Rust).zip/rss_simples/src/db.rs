//! Persistência em SQLite (arquivo `rss.db`).

use crate::feed::NewArticle;
use chrono::Utc;
use rusqlite::{params, Connection, Result};
use serde::Serialize;

pub struct Db {
    conn: Connection,
}

#[derive(Serialize)]
pub struct Feed {
    pub id: i64,
    pub url: String,
    pub title: Option<String>,
    pub etag: Option<String>,
    pub last_modified: Option<String>,
    pub last_checked: Option<String>,
    pub last_success: Option<String>,
    pub failure_count: i64,
    pub last_error: Option<String>,
}

#[derive(Serialize)]
pub struct Article {
    pub id: i64,
    pub feed_title: String,
    pub title: String,
    pub author: Option<String>,
    pub link: Option<String>,
    pub published: Option<String>,
    pub summary: Option<String>,
    pub fetched_at: String,
    pub is_read: bool,
    pub is_favorite: bool,
}

#[derive(Default)]
pub struct Filter {
    pub feed_id: Option<i64>,
    pub unread_only: bool,
    pub favorites_only: bool,
    pub search: Option<String>,
}

/// Máximo de artigos mostrados por consulta.
const ARTICLE_LIMIT: usize = 30;

fn now() -> String {
    Utc::now().to_rfc3339()
}

impl Db {
    pub fn open(path: &str) -> Result<Self> {
        Self::init(Connection::open(path)?)
    }

    #[cfg(test)]
    pub fn open_in_memory() -> Result<Self> {
        Self::init(Connection::open_in_memory()?)
    }

    fn init(conn: Connection) -> Result<Self> {
        conn.pragma_update(None, "foreign_keys", "ON")?;
        conn.execute_batch(
            "CREATE TABLE IF NOT EXISTS feeds (
                id INTEGER PRIMARY KEY,
                url TEXT NOT NULL UNIQUE,
                title TEXT,
                etag TEXT,
                last_modified TEXT,
                last_checked TEXT,
                last_success TEXT,
                failure_count INTEGER NOT NULL DEFAULT 0,
                last_error TEXT
            );
            CREATE TABLE IF NOT EXISTS articles (
                id INTEGER PRIMARY KEY,
                feed_id INTEGER NOT NULL REFERENCES feeds(id) ON DELETE CASCADE,
                key TEXT NOT NULL,
                title TEXT NOT NULL,
                author TEXT,
                link TEXT,
                published TEXT,
                summary TEXT,
                fetched_at TEXT NOT NULL,
                is_read INTEGER NOT NULL DEFAULT 0,
                is_favorite INTEGER NOT NULL DEFAULT 0,
                UNIQUE(feed_id, key)   -- <- impede artigos duplicados
            );",
        )?;
        Ok(Self { conn })
    }

    // ---- feeds ----

    /// Cadastra o feed. Retorna `false` se a URL já estava cadastrada.
    pub fn add_feed(&self, url: &str) -> Result<bool> {
        Ok(self
            .conn
            .execute("INSERT OR IGNORE INTO feeds(url) VALUES (?1)", [url])?
            > 0)
    }

    pub fn remove_feed(&self, id: i64) -> Result<bool> {
        Ok(self.conn.execute("DELETE FROM feeds WHERE id = ?1", [id])? > 0)
    }

    pub fn list_feeds(&self) -> Result<Vec<Feed>> {
        let mut stmt = self.conn.prepare(
            "SELECT id, url, title, etag, last_modified, last_checked, last_success, failure_count, last_error
             FROM feeds ORDER BY id",
        )?;
        let rows = stmt.query_map([], |r| {
            Ok(Feed {
                id: r.get(0)?,
                url: r.get(1)?,
                title: r.get(2)?,
                etag: r.get(3)?,
                last_modified: r.get(4)?,
                last_checked: r.get(5)?,
                last_success: r.get(6)?,
                failure_count: r.get(7)?,
                last_error: r.get(8)?,
            })
        })?;
        rows.collect()
    }

    /// Feed baixado com sucesso: guarda artigos novos e os dados do cache HTTP.
    /// Retorna quantos artigos eram realmente novos.
    pub fn save_success(
        &self,
        feed_id: i64,
        title: Option<&str>,
        etag: Option<&str>,
        last_modified: Option<&str>,
        articles: &[NewArticle],
    ) -> Result<usize> {
        let now = now();
        // Transação: ou grava tudo (artigos + dados do feed) ou nada, e com um único acesso ao disco.
        let tx = self.conn.unchecked_transaction()?;
        let mut new_count = 0;
        for a in articles {
            // INSERT OR IGNORE: se (feed_id, key) já existe, o banco ignora.
            new_count += tx.execute(
                "INSERT OR IGNORE INTO articles
                 (feed_id, key, title, author, link, published, summary, fetched_at)
                 VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8)",
                params![
                    feed_id,
                    a.key,
                    a.title,
                    a.author,
                    a.link,
                    a.published,
                    a.summary,
                    now
                ],
            )?;
        }
        tx.execute(
            "UPDATE feeds SET title = COALESCE(?2, title), etag = ?3, last_modified = ?4,
             last_checked = ?5, last_success = ?5, failure_count = 0, last_error = NULL WHERE id = ?1",
            params![feed_id, title, etag, last_modified, now],
        )?;
        tx.commit()?;
        Ok(new_count)
    }

    pub fn save_not_modified(&self, feed_id: i64) -> Result<()> {
        self.conn.execute(
            "UPDATE feeds SET last_checked = ?2, last_success = ?2, failure_count = 0, last_error = NULL WHERE id = ?1",
            params![feed_id, now()],
        )?;
        Ok(())
    }

    pub fn save_failure(&self, feed_id: i64, error: &str) -> Result<()> {
        self.conn.execute(
            "UPDATE feeds SET last_checked = ?2, failure_count = failure_count + 1, last_error = ?3 WHERE id = ?1",
            params![feed_id, now(), error],
        )?;
        Ok(())
    }

    // ---- artigos ----

    pub fn list_articles(&self, f: &Filter) -> Result<Vec<Article>> {
        let mut sql = String::from(
            "SELECT a.id, COALESCE(f.title, f.url), a.title, a.author, a.link, a.published,
                    a.summary, a.fetched_at, a.is_read, a.is_favorite
             FROM articles a JOIN feeds f ON f.id = a.feed_id WHERE 1=1",
        );
        let mut args: Vec<rusqlite::types::Value> = Vec::new();
        if let Some(id) = f.feed_id {
            sql += " AND a.feed_id = ?";
            args.push(id.into());
        }
        if f.unread_only {
            sql += " AND a.is_read = 0";
        }
        if f.favorites_only {
            sql += " AND a.is_favorite = 1";
        }
        if let Some(q) = &f.search {
            sql += " AND (a.title LIKE ? OR a.summary LIKE ?)";
            args.push(format!("%{q}%").into());
            args.push(format!("%{q}%").into());
        }
        sql += &format!(" ORDER BY COALESCE(a.published, a.fetched_at) DESC LIMIT {ARTICLE_LIMIT}");

        let mut stmt = self.conn.prepare(&sql)?;
        let rows = stmt.query_map(rusqlite::params_from_iter(args), |r| {
            Ok(Article {
                id: r.get(0)?,
                feed_title: r.get(1)?,
                title: r.get(2)?,
                author: r.get(3)?,
                link: r.get(4)?,
                published: r.get(5)?,
                summary: r.get(6)?,
                fetched_at: r.get(7)?,
                is_read: r.get(8)?,
                is_favorite: r.get(9)?,
            })
        })?;
        rows.collect()
    }

    pub fn set_read(&self, id: i64, read: bool) -> Result<bool> {
        Ok(self.conn.execute(
            "UPDATE articles SET is_read = ?2 WHERE id = ?1",
            params![id, read],
        )? > 0)
    }

    pub fn set_favorite(&self, id: i64, favorite: bool) -> Result<bool> {
        Ok(self.conn.execute(
            "UPDATE articles SET is_favorite = ?2 WHERE id = ?1",
            params![id, favorite],
        )? > 0)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn art(key: &str, titulo: &str) -> NewArticle {
        NewArticle {
            key: key.into(),
            title: titulo.into(),
            author: None,
            link: None,
            published: None,
            summary: Some(format!("resumo de {titulo}")),
        }
    }

    fn db_com_feed() -> Db {
        let db = Db::open_in_memory().unwrap();
        db.add_feed("https://x.com/feed").unwrap();
        db
    }

    #[test]
    fn nao_salva_artigo_duplicado() {
        let db = db_com_feed();
        let lote = [art("1", "A"), art("2", "B")];
        assert_eq!(db.save_success(1, None, None, None, &lote).unwrap(), 2);
        assert_eq!(db.save_success(1, None, None, None, &lote).unwrap(), 0); // reprocessar
        assert_eq!(db.list_articles(&Filter::default()).unwrap().len(), 2);
    }

    #[test]
    fn feed_repetido_nao_e_cadastrado_de_novo() {
        let db = db_com_feed();
        assert!(!db.add_feed("https://x.com/feed").unwrap());
        assert_eq!(db.list_feeds().unwrap().len(), 1);
    }

    #[test]
    fn lido_e_favorito() {
        let db = db_com_feed();
        db.save_success(1, None, None, None, &[art("1", "A"), art("2", "B")])
            .unwrap();
        assert!(db.set_read(1, true).unwrap());
        let nao_lidos = db
            .list_articles(&Filter {
                unread_only: true,
                ..Default::default()
            })
            .unwrap();
        assert_eq!(nao_lidos.len(), 1);

        db.set_favorite(2, true).unwrap();
        let favs = db
            .list_articles(&Filter {
                favorites_only: true,
                ..Default::default()
            })
            .unwrap();
        assert_eq!(favs.len(), 1);
        assert!(!db.set_read(999, true).unwrap()); // id inexistente
    }

    #[test]
    fn filtra_por_feed_e_pesquisa() {
        let db = db_com_feed();
        db.add_feed("https://y.com/feed").unwrap();
        db.save_success(1, None, None, None, &[art("1", "Rust novo")])
            .unwrap();
        db.save_success(
            2,
            None,
            None,
            None,
            &[art("1", "Python novo"), art("2", "Rust antigo")],
        )
        .unwrap();

        let so_feed2 = db
            .list_articles(&Filter {
                feed_id: Some(2),
                ..Default::default()
            })
            .unwrap();
        assert_eq!(so_feed2.len(), 2);
        let rust = db
            .list_articles(&Filter {
                search: Some("rust".into()),
                ..Default::default()
            })
            .unwrap();
        assert_eq!(rust.len(), 2);
    }

    #[test]
    fn falhas_sao_contadas_e_zeradas_no_sucesso() {
        let db = db_com_feed();
        db.save_failure(1, "HTTP 500").unwrap();
        db.save_failure(1, "HTTP 500").unwrap();
        let f = &db.list_feeds().unwrap()[0];
        assert_eq!(
            (f.failure_count, f.last_error.as_deref()),
            (2, Some("HTTP 500"))
        );

        db.save_success(1, Some("Meu feed"), Some("\"e\""), None, &[])
            .unwrap();
        let f = &db.list_feeds().unwrap()[0];
        assert_eq!(f.failure_count, 0);
        assert_eq!(f.etag.as_deref(), Some("\"e\""));
    }

    #[test]
    fn remover_feed_apaga_artigos() {
        let db = db_com_feed();
        db.save_success(1, None, None, None, &[art("1", "A")])
            .unwrap();
        assert!(db.remove_feed(1).unwrap());
        assert!(db.list_articles(&Filter::default()).unwrap().is_empty());
    }
}
