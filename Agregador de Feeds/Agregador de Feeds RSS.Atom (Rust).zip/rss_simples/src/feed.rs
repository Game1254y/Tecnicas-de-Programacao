//! Baixar (HTTP) e interpretar (RSS/Atom) um feed. Nada aqui toca no banco.

use std::time::Duration;

const TIMEOUT: Duration = Duration::from_secs(10);

/// Artigo ainda não salvo no banco.
pub struct NewArticle {
    pub key: String, // chave anti-duplicata
    pub title: String,
    pub author: Option<String>,
    pub link: Option<String>,
    pub published: Option<String>, // RFC 3339
    pub summary: Option<String>,
}

/// Resultado de consultar um feed.
pub enum Fetched {
    /// Servidor respondeu 304: nada mudou, nada foi baixado.
    NotModified,
    Updated {
        title: Option<String>,
        articles: Vec<NewArticle>,
        etag: Option<String>,
        last_modified: Option<String>,
    },
}

pub fn client() -> Result<reqwest::Client, String> {
    reqwest::Client::builder()
        .timeout(TIMEOUT) // feed lento não trava tudo
        .user_agent("rss_simples/0.1")
        .build()
        .map_err(|e| e.to_string())
}

pub fn validate_url(url: &str) -> Result<(), String> {
    match reqwest::Url::parse(url) {
        Ok(u) if u.scheme() == "http" || u.scheme() == "https" => Ok(()),
        _ => Err(format!("URL inválida: {url} (use http:// ou https://)")),
    }
}

/// Baixa o feed. Se já temos etag/last_modified, pergunta ao servidor
/// "mudou desde então?" (If-None-Match / If-Modified-Since).
pub async fn fetch(
    client: &reqwest::Client,
    url: &str,
    etag: Option<&str>,
    last_modified: Option<&str>,
) -> Result<Fetched, String> {
    validate_url(url)?;
    let mut req = client.get(url);
    if let Some(e) = etag {
        req = req.header("If-None-Match", e);
    }
    if let Some(l) = last_modified {
        req = req.header("If-Modified-Since", l);
    }

    let resp = req.send().await.map_err(|e| {
        if e.is_timeout() {
            "tempo esgotado".to_string()
        } else {
            format!("falha de rede: {e}")
        }
    })?;

    if resp.status().as_u16() == 304 {
        return Ok(Fetched::NotModified);
    }
    if !resp.status().is_success() {
        return Err(format!("HTTP {}", resp.status().as_u16()));
    }

    let header = |name: &str| {
        resp.headers()
            .get(name)
            .and_then(|v| v.to_str().ok())
            .map(String::from)
    };
    let (etag, last_modified) = (header("etag"), header("last-modified"));

    let body = resp
        .bytes()
        .await
        .map_err(|e| format!("falha ao ler resposta: {e}"))?;
    let (title, articles) = parse(&body)?;
    Ok(Fetched::Updated {
        title,
        articles,
        etag,
        last_modified,
    })
}

/// Interpreta RSS ou Atom (a crate feed-rs reconhece o formato sozinha).
pub fn parse(bytes: &[u8]) -> Result<(Option<String>, Vec<NewArticle>), String> {
    let feed = feed_rs::parser::parse(bytes)
        .map_err(|e| format!("não é um feed RSS/Atom válido ({e})"))?;

    let articles = feed
        .entries
        .into_iter()
        .filter_map(|e| {
            let title = e
                .title
                .map(|t| t.content.trim().to_string())
                .filter(|t| !t.is_empty());
            let link = e.links.first().map(|l| l.href.clone());
            // registro incompleto: sem título e sem link não serve para nada
            if title.is_none() && link.is_none() {
                return None;
            }
            Some(NewArticle {
                key: dedup_key(&e.id, link.as_deref(), title.as_deref()),
                title: title.or_else(|| link.clone()).unwrap_or_default(),
                author: e.authors.first().map(|p| p.name.clone()),
                link,
                published: e.published.or(e.updated).map(|d| d.to_rfc3339()),
                summary: e.summary.map(|s| s.content),
            })
        })
        .collect();

    Ok((feed.title.map(|t| t.content), articles))
}

/// Estratégia anti-duplicata: usa o GUID do artigo; se não houver,
/// o link; se também não houver, o título.
pub fn dedup_key(guid: &str, link: Option<&str>, title: Option<&str>) -> String {
    [Some(guid), link, title]
        .into_iter()
        .flatten()
        .map(str::trim)
        .find(|s| !s.is_empty())
        .unwrap_or_default()
        .to_string()
}

#[cfg(test)]
mod tests {
    use super::*;

    const RSS: &str = r#"<rss version="2.0"><channel><title>Blog</title><link>https://x.com</link><description>d</description>
        <item><title>Post 1</title><link>https://x.com/1</link><guid>g1</guid><description>Resumo</description></item>
        <item><title>Post 2</title><link>https://x.com/2</link></item>
        <item><description>sem título nem link</description></item>
        </channel></rss>"#;

    const ATOM: &str = r#"<feed xmlns="http://www.w3.org/2005/Atom"><title>Atom</title><id>f</id><updated>2025-01-01T00:00:00Z</updated>
        <entry><title>Entrada</title><id>e1</id><link href="https://x.com/a"/><updated>2025-01-01T00:00:00Z</updated><author><name>Ana</name></author></entry>
        </feed>"#;

    #[test]
    fn le_rss_e_descarta_item_incompleto() {
        let (titulo, artigos) = parse(RSS.as_bytes()).unwrap();
        assert_eq!(titulo.as_deref(), Some("Blog"));
        assert_eq!(artigos.len(), 2);
        assert_eq!(artigos[0].key, "g1");
    }

    #[test]
    fn le_atom() {
        let (_, artigos) = parse(ATOM.as_bytes()).unwrap();
        assert_eq!(artigos.len(), 1);
        assert_eq!(artigos[0].author.as_deref(), Some("Ana"));
        assert!(artigos[0].published.is_some());
    }

    #[test]
    fn xml_invalido_html_e_vazio_viram_erro() {
        assert!(parse(b"<rss><channel><title>quebrado").is_err());
        assert!(parse(b"<html><body>oi</body></html>").is_err());
        assert!(parse(b"").is_err());
    }

    #[test]
    fn feed_vazio_nao_e_erro() {
        let xml = r#"<rss version="2.0"><channel><title>V</title><link>https://x.com</link><description>d</description></channel></rss>"#;
        assert!(parse(xml.as_bytes()).unwrap().1.is_empty());
    }

    #[test]
    fn chave_prefere_guid_depois_link_depois_titulo() {
        assert_eq!(dedup_key("g", Some("l"), Some("t")), "g");
        assert_eq!(dedup_key("  ", Some("l"), Some("t")), "l");
        assert_eq!(dedup_key("", None, Some("t")), "t");
    }

    #[test]
    fn valida_url() {
        assert!(validate_url("https://site.com/feed").is_ok());
        assert!(validate_url("banana").is_err());
        assert!(validate_url("ftp://site.com/feed").is_err());
    }
}
