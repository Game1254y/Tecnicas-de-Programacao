# Agregador de Feeds RSS/Atom (Rust)

**Integrantes:** Guilherme e Ana _(completar com sobrenomes e RA)_

Programa em Rust que cadastra feeds RSS/Atom, atualiza todos ao mesmo tempo, guarda os
artigos em um banco SQLite e permite ler, filtrar e pesquisar. Pode ser usado pelo
**terminal** ou por uma **interface web** (HTML/CSS/JavaScript) servida pelo próprio programa.

## Como executar

Requisito: Rust instalado (https://rustup.rs). Não é preciso instalar mais nada.

```bash
cargo run -- serve          # abre a interface; acesse http://127.0.0.1:3000
```

Também funciona pelo terminal:

```bash
cargo run -- add https://blog.rust-lang.org/feed.xml
cargo run -- update
cargo run -- list --unread
cargo test                  # 16 testes automatizados
```

Comandos: `add <url>` · `remove <id>` · `feeds` · `update` · `serve` ·
`list [--unread] [--fav] [--feed ID] [--search TEXTO]` ·
`read <id>` · `unread <id>` · `fav <id>` · `unfav <id>`

Os dados ficam no arquivo `rss.db`, criado na pasta onde o programa é executado.

## Estrutura

```
src/
  main.rs   comandos do terminal e a atualização dos feeds (update_all)
  feed.rs   baixar (HTTP) + interpretar RSS/Atom + chave anti-duplicata
  db.rs     banco SQLite: feeds, artigos, filtros, contadores de falha
  web.rs    servidor web local e API JSON
web/
  index.html  estrutura da página
  style.css   aparência (cores, layout, responsivo)
  app.js      comunicação da página com a API do Rust
```

```
Navegador (HTML/CSS/JS) --fetch--> web.rs --> db.rs (SQLite)
                                      |
                                      +--> update_all --> feed.rs --> internet
```

A página **não acessa o banco**: ela pede tudo ao Rust pela API abaixo.

| Método | Caminho | O que faz |
|---|---|---|
| GET | `/api/feeds` | lista feeds e seu estado |
| POST | `/api/feeds` | cadastra feed (`{"url": "..."}`) |
| DELETE | `/api/feeds/{id}` | remove feed e seus artigos |
| POST | `/api/update` | atualiza todos os feeds |
| GET | `/api/articles?unread=1&fav=1&feed=2&search=texto` | lista artigos (filtros opcionais) |
| POST | `/api/articles/{id}/read` · `unread` · `fav` · `unfav` | marca o artigo |

## Dependências

`tokio` (async) · `reqwest` (HTTP) · `feed-rs` (RSS/Atom) · `rusqlite` (SQLite) ·
`futures` · `chrono` (datas) · `tiny_http` (servidor web) · `serde`/`serde_json` (JSON)

## Decisões técnicas

- **Concorrência:** `buffer_unordered(5)` baixa até 5 feeds ao mesmo tempo, sem esperar um
  terminar para começar outro. O banco é gravado depois, em sequência (sem locks).
- **Duplicidade:** cada artigo tem uma chave = GUID, ou link, ou título (nessa ordem).
  A tabela tem `UNIQUE(feed_id, key)` e a gravação usa `INSERT OR IGNORE`.
- **Atualização eficiente:** guardamos `etag` e `last_modified` de cada feed e enviamos
  `If-None-Match` / `If-Modified-Since`. Se nada mudou, o servidor responde 304 sem corpo:
  não há download, parsing nem artigos novos para gravar. Também guardamos `last_checked`,
  `last_success`, `failure_count` e `last_error`.
- **Gravação:** os artigos de um feed e os dados do feed vão em uma única transação SQLite.
- **Erros:** todo erro previsível (URL inválida, sem rede, timeout de 10 s, HTTP 404/500,
  XML inválido, página que não é feed, feed vazio, item sem título e link) vira uma
  mensagem, é gravado no feed e não interrompe os demais.
- **Interface:** os arquivos de `web/` são embutidos no programa (`include_str!`), então o
  executável é autossuficiente. O servidor só aceita conexões de `127.0.0.1` (o próprio computador).
- **Segurança na página:** textos dos feeds são inseridos com `textContent` (nunca como HTML)
  e só links `http(s)` viram links clicáveis.

## Funcionalidades

Cadastrar/remover/listar feeds · atualizar todos · detectar feeds com erro · RSS 2.0 e
Atom · atualização concorrente com limite · persistência · listar todos/não lidos ·
lido/não lido · favoritos · filtro por feed · pesquisa no título e resumo · deduplicação ·
HTTP condicional · interface web · testes.

## Limitações

- A atualização é sempre de todos os feeds (não há botão para atualizar só um).
- Pesquisa só no título e no resumo, com `LIKE` simples.
- Chave de duplicata simples: se um site trocar o GUID de um artigo, ele entra de novo.
- O servidor web atende um pedido por vez e é só para uso local (sem login).
- Mostra no máximo 30 artigos por consulta.
- Sem OPML, notificações, imagens ou execução em segundo plano.

## Uso de Inteligência Artificial

_(Editar com a descrição real.)_ O código, a interface e a documentação foram gerados com
apoio do Claude (Anthropic) a partir do enunciado; a equipe revisou, executou, testou e é
responsável por todo o código.
